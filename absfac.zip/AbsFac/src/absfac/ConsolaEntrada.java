package absfac;

import java.util.Scanner;

public class ConsolaEntrada implements IEntrada {
    private Scanner scanner = new Scanner(System.in);

    @Override
    public String ingresarDatos() {
        System.out.print("Ingrese un dato (Consola): ");
        return scanner.nextLine();
    }
}
