package absfac;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;

public class JFrameSalida extends JFrame implements ISalida {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    JFrameSalida frame = new JFrameSalida("Ejemplo de mensaje");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public JFrameSalida(String mensaje) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 450, 200);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblMensaje = new JLabel(mensaje);
        lblMensaje.setBounds(20, 20, 400, 30);
        contentPane.add(lblMensaje);
    }

    @Override
    public void mostrarDatos(String mensaje) {
        EventQueue.invokeLater(() -> {
            JFrameSalida frame = new JFrameSalida(mensaje);
            frame.setVisible(true);
        });
    }
}
