package absfac;

public class WebFactory implements FactoryAbstracta {
    @Override
    public IEntrada crearEntrada() {
        return new WebEntrada();
    }

    @Override
    public ISalida crearSalida() {
        return new WebSalida();
    }
}
