package absfac;

public class AdaptadorDatos {
    public static String convertirAString(Object dato) {
        return dato.toString();
    }
}
