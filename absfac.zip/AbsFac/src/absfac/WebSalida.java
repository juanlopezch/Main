package absfac;

public class WebSalida implements ISalida {
    @Override
    public void mostrarDatos(String mensaje) {
        System.out.println("Salida en Web: <p>" + mensaje + "</p>");
    }
}
