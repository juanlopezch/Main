package absfac;

public class ConsolaSalida implements ISalida {
    @Override
    public void mostrarDatos(String mensaje) {
        System.out.println("Salida en Consola: " + mensaje);
    }
}
