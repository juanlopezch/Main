package absfac;

import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        while (true) { // Permite cambiar de interfaz sin reiniciar el programa
            // Opciones para entrada y salida
            String[] opcionesEntrada = {"Consola", "JFrame", "Web"};
            String[] opcionesSalida = {"Consola", "JFrame", "Web"};

            // Selección del usuario
            String seleccionEntrada = (String) JOptionPane.showInputDialog(
                    null,
                    "Seleccione el tipo de entrada:",
                    "Configuración de Entrada",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opcionesEntrada,
                    opcionesEntrada[0]
            );

            String seleccionSalida = (String) JOptionPane.showInputDialog(
                    null,
                    "Seleccione el tipo de salida:",
                    "Configuración de Salida",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    opcionesSalida,
                    opcionesSalida[0]
            );

            // Salir si el usuario cancela
            if (seleccionEntrada == null || seleccionSalida == null) {
                JOptionPane.showMessageDialog(null, "Programa finalizado.");
                break;
            }

            // Crear la fábrica adecuada
            FactoryAbstracta factory;
            if ("Consola".equals(seleccionEntrada) && "Consola".equals(seleccionSalida)) {
                factory = new ConsolaFactory();
            } else if ("JFrame".equals(seleccionEntrada) && "JFrame".equals(seleccionSalida)) {
                factory = new JFrameFactory();
            } else if ("Web".equals(seleccionEntrada) && "Web".equals(seleccionSalida)) {
                factory = new WebFactory();
            } else {
                JOptionPane.showMessageDialog(null, "Combinación no soportada aún.");
                continue;
            }

            // Crear entrada y salida
            IEntrada entrada = factory.crearEntrada();
            ISalida salida = factory.crearSalida();

            // Capturar datos y mostrarlos
            String datos = entrada.ingresarDatos();
            salida.mostrarDatos("Datos ingresados: " + datos);

            // Preguntar si quiere probar otra configuración
            int respuesta = JOptionPane.showConfirmDialog(
                    null,
                    "¿Desea probar otra configuración?",
                    "Reiniciar",
                    JOptionPane.YES_NO_OPTION
            );

            if (respuesta == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(null, "Programa finalizado.");
                break; // Finaliza el programa
            }
        }
    }
}
