package absfac;

public interface IEntrada {
    String ingresarDatos();
}
