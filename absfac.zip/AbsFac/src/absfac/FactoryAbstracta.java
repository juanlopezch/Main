package absfac;

public interface FactoryAbstracta {
    IEntrada crearEntrada();
    ISalida crearSalida();
}
