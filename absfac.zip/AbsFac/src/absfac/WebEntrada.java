package absfac;

public class WebEntrada implements IEntrada {
    @Override
    public String ingresarDatos() {
        return "Dato recibido desde una página web";
    }
}
