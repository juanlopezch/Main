package absfac;

public class ConsolaFactory implements FactoryAbstracta {
    @Override
    public IEntrada crearEntrada() {
        return new ConsolaEntrada();
    }

    @Override
    public ISalida crearSalida() {
        return new ConsolaSalida();
    }
}
