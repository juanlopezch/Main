package absfac;

public class JFrameFactory implements FactoryAbstracta {
    @Override
    public IEntrada crearEntrada() {
        return new JFrameEntrada();
    }

    @Override
    public ISalida crearSalida() {
        return new JFrameSalida("");
    }
}
