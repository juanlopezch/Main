package absfac;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JFrameEntrada extends JFrame implements IEntrada {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textField;
    private String datoIngresado = "";

    public JFrameEntrada() {
        setTitle("Ingresar Datos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 200);
        setLocationRelativeTo(null); // Centrar en pantalla

        contentPane = new JPanel();
        contentPane.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(contentPane);
        contentPane.setLayout(new BorderLayout(10, 10));

        JLabel lblMensaje = new JLabel("Ingrese un dato:");
        lblMensaje.setFont(new Font("Arial", Font.BOLD, 14));
        contentPane.add(lblMensaje, BorderLayout.NORTH);

        textField = new JTextField();
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        contentPane.add(textField, BorderLayout.CENTER);

        JButton btnIngresar = new JButton("Aceptar");
        btnIngresar.setFont(new Font("Arial", Font.BOLD, 14));
        btnIngresar.setBackground(new Color(50, 150, 250)); // Azul claro
        btnIngresar.setForeground(Color.WHITE);
        btnIngresar.setFocusPainted(false);
        btnIngresar.setBorderPainted(false);
        btnIngresar.setOpaque(true);

        // Agregar efecto hover
        btnIngresar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnIngresar.setBackground(new Color(30, 130, 230)); // Azul más oscuro
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnIngresar.setBackground(new Color(50, 150, 250));
            }
        });

        btnIngresar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                datoIngresado = textField.getText().trim();
                if (!datoIngresado.isEmpty()) {
                    dispose(); // Cierra la ventana después de ingresar el dato
                } else {
                    JOptionPane.showMessageDialog(null, "Por favor ingrese un dato.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        contentPane.add(btnIngresar, BorderLayout.SOUTH);
    }

    @Override
    public String ingresarDatos() {
        setVisible(true);
        while (datoIngresado.isEmpty()) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        return datoIngresado;
    }
}
