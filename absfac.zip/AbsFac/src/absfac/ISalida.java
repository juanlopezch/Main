package absfac;

public interface ISalida {
    void mostrarDatos(String mensaje);
}
