/**
 * 
 */
/**
 * 
 */
module AbsFac {
	requires java.desktop;
}